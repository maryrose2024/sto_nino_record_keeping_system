<?php
    session_start();
    $title = "dashboard";
    
    include 'includes/header.php';
    include 'includes/navbar.php';
    include 'includes/scripts.php';

?>
<!-- Content Wrapper -->
<div id="content-wrapper" class="d-flex flex-column">
    <?php include('header_nav.php');?>
    <!-- Main Content -->
    <div id="content">
        <div class="col-12 col-xl-12">
            <div class="col mt-4">
                <h1 class="mb-2 text-uppercase fw-bolder">Event Calendar</h1>
                <hr>
                <div class="d-flex gap-2 align-items-center">
                    <button type="button" class="btn btn-primary mb-3" data-bs-toggle="modal"
                        data-bs-target="#addScheduleModal">
                        Add Schedule
                    </button>
                    <button type="button" onclick="window.location.href='schedules.php'" class="btn btn-secondary mb-3">
                        Schedule List
                    </button>
                </div>

                </ul>
            </div>
            <div style="background-color: white; text-decoration:black;" class="col-md-12">
                <div id="calendar"></div>
            </div>
        </div>
    </div>

    <!-- Modal for event details, edit, and delete -->
    <div class="modal fade" id="eventModal" tabindex="-1" aria-labelledby="eventModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="eventTitle"></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Event Name:</p>
                    <h2 id="eventName"></h2>
                    <p>Location (Pamayanan):</p>
                    <h2 id="eventPlace"></h2>
                    <p>Date & Time:</p>
                    <h2 id="eventTime"></h2>
                    <!-- Add the following lines to display the priest and client_name -->
                    <p>Priest:</p>
                    <h2 id="eventPriest"></h2>
                    <p>Client Name:</p>
                    <h2 id="eventClientName"></h2>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" id="editEventButton">Edit</button>
                    <button type="button" class="btn btn-danger" id="deleteEventButton">Delete</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal for adding a schedule -->
    <div class="modal fade" id="addScheduleModal" tabindex="-1" aria-labelledby="addScheduleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title fw-bolder" id="addScheduleModalLabel">Add Schedule</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="addScheduleForm" method="POST" action="">
                        <div class="mb-3">
                            <label for="status" class="form-label">Event Name</label>
                            <select class="form-select" id="event_name" name="event_name" required>
                                <option value="Mass">Mass (Misa)</option>
                                <option value="Blessing">Blessing</option>
                                <option value="Christening">Christening (Binyag)</option>
                                <option value="Communion">Communion (Komunyon)</option>
                                <option value="Confirmation">Confirmation (Kumpil)</option>
                                <option value="Wedding">Wedding (Kasal)</option>
                                <option value="Conversion">Conversion (Konbersiyon)</option>
                                <option value="Funeral">Funeral (Libing)</option>
                            </select>
                        </div>
                        <?php
                            $sql = "SELECT brgy FROM address"; 
                            $result = $conn->query($sql);

                            if ($result->num_rows > 0) {
                                echo '<div class="mb-3">';
                                echo '<label for="eventplace" class="form-label">Location (Pamayanan)</label>';
                                echo '<select class="form-select" id="address" name="address" required>';
                                while ($row = $result->fetch_assoc()) {
                                    echo '<option value="' . $row['brgy'] . '">' . $row['brgy'] . '</option>';
                                }
                                echo '</select>';
                                echo '</div>';
                            } else {
                                echo "No addresses found in the database.";
                            }
                        ?>
                        <div class="mb-3">
                            <label for="datetime" class="form-label">Date & Time</label>
                            <input type="datetime-local" class="form-control" id="datetime" name="datetime" required>
                        </div>

                        <?php
                            $query = "SELECT first_name, middle_name, last_name FROM priest";
                            $result = mysqli_query($conn, $query);

                            if ($result) {
                                echo '<div class="mb-3">';
                                echo '<label for="priest" class="form-label">Priest</label>';
                                echo '<select class="form-select" id="priest" name="priest" required>';

                                while ($row = mysqli_fetch_assoc($result)) {
                                    $formatted_name = 'Fr. ' . $row['first_name'] . ' ' . substr($row['middle_name'], 0, 1) . '. ' . $row['last_name'];
                                    echo '<option value="' . $formatted_name . '">' . $formatted_name . '</option>';
                                }

                                echo '</select>';
                                echo '</div>';
                            } else {
                                echo 'Error fetching data from the database';
                            }
                        ?>

                        <div class="mb-3">
                            <label for="client_name" class="form-label">Client Name</label>
                            <input type="text" class="form-control" id="client_name" name="client_name" required>
                        </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary" name="addSchedule">Submit</button>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>
</div>
<!-- backend: inserting_new_schedules -->
<?php
    include 'connect.php';

    if (isset($_POST['addSchedule'])) {
        $user_id = $_SESSION['user_id'];
        $event_name = $_POST['event_name'];
        $client_name = $_POST['client_name'];
        $address = $_POST['address'];
        $datetime = $_POST['datetime'];

        list($date, $time) = explode('T', $datetime);
        $time = date("h:i A", strtotime($time));

        $timestamp = strtotime($datetime);
        $date = date('Y-m-d', $timestamp);
        $time = date('H:i', $timestamp); 
        $ampm = date('A', $timestamp); 
        $time = $time . ' ' . $ampm;

        $priest = $_POST['priest']; 
        $clientName = $_POST['clientname']; 

        $sql = "INSERT INTO `schedules` (`event_name`, `priest`, `client_name`, `added_by`,`address`, `date`, `time`) 
                VALUES ('$event_name', '$priest', '$client_name', '$user_id', '$address', '$date', '$time')";

        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('New Schedule added successfully.'); window.location.href='schedules.php';</script>";
        } else {
            echo "<script>alert('Error adding new Schedule'); window.location.href='schedules.php';</script>";
        }
    }

?>


</body>

<script>
$(document).ready(function() {
    let calendarEl = document.getElementById('calendar');
    let calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        events: {
            url: 'get_schedules.php',
            method: 'GET'
        },
        eventClick: function(info) {
            let event = info.event;
            let modal = new bootstrap.Modal($('#eventModal'), {
                keyboard: true
            });

            if (event) {
                $('#eventTitle').html(event.title);
                $('#eventName').html(event.title);
                $('#eventTime').html(event.startStr);
                $('#eventPriest').html(event.extendedProps.priest);
                $('#eventClientName').html(event.extendedProps.client_name);

                $('#editEventButton').click(function() {
                    window.location.href = 'schedules_edit.php?id=' + event.id;
                });

                $('#deleteEventButton').click(function() {
                    if (confirm('Are you sure you want to delete this event?')) {
                        $.ajax({
                            url: 'schedules_delete.php',
                            method: 'POST',
                            data: {
                                id: event.id
                            },
                            success: function(response) {
                                if (response.success) {
                                    calendar.refetchEvents();
                                    modal.hide();
                                    updateScheduleList();
                                } else {
                                    alert('Error deleting event.');
                                }
                            },
                            error: function() {
                                alert('Error deleting event.');
                            }
                        });
                    }
                });

                updateScheduleList();
            } else {
                $('#eventTitle').html('No Event Selected');
                $('#eventName').html('');
                $('#eventTime').html('');
            }
            modal.show();
        }
    });

    calendar.render();

    function updateScheduleList() {
        $.ajax({
            url: 'get_schedules.php',
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                let scheduleList = $('#scheduleList');
                scheduleList.empty();

                $.each(response, function(index, schedule) {
                    let listItem = $('<li>').html('<strong>' + schedule.title +
                        ':</strong> ' + schedule.start);
                    scheduleList.append(listItem);
                });
            }
        });
    }
    updateScheduleList();
});
</script>


</html>